package com.nr.springsecurity.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nr.springsecurity.demo.repository.PlayerRepository;
import com.nr.springsecurity.entity.Player;
@Service
public class PlayerService {
@Autowired
private PlayerRepository playerRepo;

@Transactional
public List<Player> getPlayers() {
	return playerRepo.getPlayers();
}
@Transactional
public Player getPlayer(int id) {
	return playerRepo.getPlayer(id);
}
@Transactional
public void saveOrUpdatePlayer(Player player) {
	playerRepo.saveOrUpdatePlayer(player);
}
}

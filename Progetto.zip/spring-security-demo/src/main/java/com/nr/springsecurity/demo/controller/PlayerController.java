package com.nr.springsecurity.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nr.springsecurity.demo.service.PlayerService;
import com.nr.springsecurity.entity.Player;

@Controller
public class PlayerController {
	@Autowired
	private PlayerService playerService;
	@GetMapping("/lista-calciatori")
	public String showAllPlayers(Model model,@RequestParam(value="pag", required =false) Integer pag) {
		List<Player> thePlayers = playerService.getPlayers();
		List<Player> thePlayersImp = new ArrayList<>();
		int pagina=1;
		if(pag!=null) {
			pagina=pag;
		}
		int nPagine=0;
		int totGiocatori=thePlayers.size();
		int nVisualizzati=10;
		int offset,limit;
		if(totGiocatori%nVisualizzati!=0)
			nPagine=(totGiocatori/nVisualizzati)+1;
		else
			nPagine=(totGiocatori/nVisualizzati);
		if(pagina==0)
			pagina=1;
		else if(pagina>nPagine)
			pagina=nPagine;
		else if(pagina==1) {
			pagina=1;
		}
		offset=(pagina-1)*nVisualizzati;
		limit=offset+nVisualizzati;
		for(int i=offset;i<limit && i<thePlayers.size();i++) {
			thePlayersImp.add(thePlayers.get(i));
		}
		model.addAttribute("players", thePlayersImp);
		model.addAttribute("page", pagina);
		return "databasePlayers";
	}
	@GetMapping("/showForm")
	public String showForm(@RequestParam("playerId") int idPlayer,Model model) {
		Player player = playerService.getPlayer(idPlayer);
		model.addAttribute("player",player);
		return "formPlayer";
	}
	@PostMapping("/savePlayers")
	public String formModificaPlayer(@ModelAttribute("player")Player player) {
		playerService.saveOrUpdatePlayer(player);
		return "redirect:/lista-calciatori";
	}
}

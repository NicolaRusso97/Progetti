package com.nr.springsecurity.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.nr.springsecurity.entity.Player;
@Repository
public interface PlayerRepository {
	public List<Player> getPlayers();
	public Player getPlayer(int id);
	public void saveOrUpdatePlayer(Player player);
	
}

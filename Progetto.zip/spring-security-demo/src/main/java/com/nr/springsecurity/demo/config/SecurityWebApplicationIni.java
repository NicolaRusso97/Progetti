package com.nr.springsecurity.demo.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SecurityWebApplicationIni
extends AbstractSecurityWebApplicationInitializer {
}
